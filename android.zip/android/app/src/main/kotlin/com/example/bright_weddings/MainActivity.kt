package com.example.bright_weddings

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
